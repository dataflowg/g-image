//
//  xcode.h
//  g_image
//
//  Created by Dataflow_G on 7/28/22.
//  Copyright © 2022 Dataflow_G. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for g_image.
FOUNDATION_EXPORT double g_imageVersionNumber;

//! Project version string for g_image.
FOUNDATION_EXPORT const unsigned char g_imageVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <g_image/PublicHeader.h>


